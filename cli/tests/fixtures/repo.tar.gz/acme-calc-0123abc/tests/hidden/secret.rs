use calc::add; #[test] fn secret() { assert_eq!(add(40, 2), 42); }
