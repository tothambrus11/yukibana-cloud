use calc::add; #[test] fn adds() { assert_eq!(add(1, 2), 3); }
